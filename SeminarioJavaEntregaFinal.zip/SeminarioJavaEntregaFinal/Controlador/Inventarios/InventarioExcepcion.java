package Controlador.Inventarios;

// Excepción 
public class InventarioExcepcion extends Exception {
    public InventarioExcepcion(String mensaje) {
        super(mensaje);
    }
}