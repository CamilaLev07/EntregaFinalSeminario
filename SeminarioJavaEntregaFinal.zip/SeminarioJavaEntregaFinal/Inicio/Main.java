package Inicio;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import Modelo.Acciones.*;
import Modelo.Personas.*;
import Modelo.Categoria;

public class Main {
    public static void main(String[] args) {

        // instancia de Gestion de inventario
        GestionInventario gestionInventario = new GestionInventario();
        Scanner scanner = new Scanner(System.in);

        int opcion = -1;

        // bucle de menu de opciones
        do {
            mostrarMenu();
            opcion = obtenerOpcion(scanner);

            // Elegir qué acción realizar
            switch (opcion) {
                case 1:
                    agregarOrdenCompra(scanner, gestionInventario);
                    break;
                case 2:
                    agregarDevolucion(scanner, gestionInventario);
                    break;
                case 3:
                    agregarVenta(scanner, gestionInventario);
                    break;
                case 4:
                    gestionInventario.agregarProducto(scanner);
                    break;
                case 5:
                    agregarCategoria(scanner, gestionInventario);
                    break;
                case 6:
                    agregarCliente(scanner, gestionInventario);
                    break;
                case 7:
                    agregarProveedor(scanner, gestionInventario);
                    break;
                case 8:
                    agregarUsuario(scanner, gestionInventario);
                    break;
                case 9:
                    agregarRol(scanner, gestionInventario); // Llamar al método agregarRol con el scanner
                    break;
                // Llamada al método consultarOrdenes
                case 10:
                    consultarOrdenes(gestionInventario); // Llama al método con el objeto gestionInventario
                    break;

                case 11:
                    gestionInventario.consultarDevoluciones(); // Llama al método en la instancia de GestionInventario
                    break;
                case 12:
                    consultarVentas(gestionInventario);
                    break;
                case 13:
                    gestionInventario.consultarClientes(); // Llama al método consultarClientes de GestionInventario
                    break;
                case 14:
                    gestionInventario.consultarProveedores(); // Llamar directamente a consultarProveedores
                    break;
                case 15:
                    gestionInventario.consultarStock(scanner);
                    break;
                case 16:
                    gestionInventario.consultarUsuarios();
                    break;
                case 17:
                    int idModificar = obtenerNumero(scanner, "Ingrese ID de Producto a modificar: ");
                    gestionInventario.modificarProducto(idModificar, scanner);
                    break;
                case 18:
                    int idEliminar = obtenerNumero(scanner, "Ingrese ID de Producto a eliminar: ");
                    gestionInventario.eliminarProducto(idEliminar);
                    break;
                case 19:
                    int idOrdenModificar = obtenerNumero(scanner, "Ingrese ID de Orden de Compra a modificar: ");
                    gestionInventario.modificarOrdenCompra(idOrdenModificar, scanner);
                    break;
                case 20:
                    int idOrdenEliminar = obtenerNumero(scanner, "Ingrese ID de Orden de Compra a eliminar: ");
                    gestionInventario.eliminarOrdenCompra(idOrdenEliminar);
                    break;
                case 21:
                    int idDevolucionModificar = obtenerNumero(scanner, "Ingrese ID de Devolución a modificar: ");
                    gestionInventario.modificarDevolucion(idDevolucionModificar, scanner);
                    break;
                case 22:
                    int idDevolucionEliminar = obtenerNumero(scanner, "Ingrese ID de Devolución a eliminar: ");
                    gestionInventario.eliminarDevolucion(idDevolucionEliminar);
                    break;
                case 23:
                    int idUsuarioModificar = obtenerNumero(scanner, "Ingrese ID de Usuario a modificar: ");
                    gestionInventario.modificarUsuario(idUsuarioModificar, scanner);
                    break;
                case 24:
                    int idUsuarioEliminar = obtenerNumero(scanner, "Ingrese ID de Usuario a eliminar: ");
                    gestionInventario.eliminarUsuario(idUsuarioEliminar);
                    break;
                case 25:
                    int idProveedorModificar = obtenerNumero(scanner, "Ingrese ID de Proveedor a modificar: ");
                    gestionInventario.modificarProveedor(idProveedorModificar, scanner);
                    break;
                case 26:
                    int idProveedorEliminar = obtenerNumero(scanner, "Ingrese ID de Proveedor a eliminar: ");
                    gestionInventario.eliminarProveedor(idProveedorEliminar);
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }

        } while (opcion != 0);

        scanner.close();
    }

    // Método de obtener opción
    private static int obtenerOpcion(Scanner scanner) {
        int opcion = -1;
        while (true) {
            try {
                System.out.print("Seleccione una opción: ");
                opcion = scanner.nextInt(); // Leer opción ingresada
                scanner.nextLine(); // Limpiar el buffer
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: Entrada inválida. Asegúrese de ingresar un número.");
                scanner.nextLine(); // Limpiar el buffer
            }
        }
        return opcion; // Retornar la opción válida
    }

    // Mostrar menú de opciones
    private static void mostrarMenu() {
        System.out.println("********************************");
        System.out.println("=== Gestión de Inventario ===");
        System.out.println("********************************");
        System.out.println("---------------------------------");
        System.out.println("********  Agregaciones  ********");
        System.out.println("---------------------------------");
        System.out.println("1. Agregar Orden de Compra");
        System.out.println("2. Agregar Devolución");
        System.out.println("3. Agregar Venta");
        System.out.println("4. Agregar Producto");
        System.out.println("5. Agregar Categoría");
        System.out.println("6. Agregar Cliente");
        System.out.println("7. Agregar Proveedor");
        System.out.println("8. Agregar Usuario");
        System.out.println("9. Agregar Rol");
        System.out.println("---------------------------------");
        System.out.println("*********  Consultas  ***********");
        System.out.println("---------------------------------");
        System.out.println("10. Consultar Órdenes de Compra");
        System.out.println("11. Consultar Devoluciones");
        System.out.println("12. Consultar Ventas");
        System.out.println("13. Consultar Clientes");
        System.out.println("14. Consultar Proveedores");
        System.out.println("15. Consultar Stock");
        System.out.println("16. Consultar Usuarios");
        System.out.println("-----------------------------------");
        System.out.println("********  Modificaciones  ********");
        System.out.println("-----------------------------------");
        System.out.println("17. Modificar Productos");
        System.out.println("19. Modificar Órdenes de Compra");
        System.out.println("21. Modificar Devoluciones");
        System.out.println("23. Modificar Usuarios");
        System.out.println("25. Modificar Proveedores");
        System.out.println("-----------------------------------");
        System.out.println("********  Eliminaciones  ********");
        System.out.println("-----------------------------------");
        System.out.println("18. Eliminar Productos");
        System.out.println("20. Eliminar Órdenes de Compra");
        System.out.println("22. Eliminar Devoluciones");
        System.out.println("24. Eliminar Usuarios");
        System.out.println("26. Eliminar Proveedores");
        System.out.println("-----------------------------------");
        System.out.println("********  Cerrar Sesion  ********");
        System.out.println("-----------------------------------");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: "); // Aquí selecciona la opción deseada
    }

    // Metodo obtener numero
    private static int obtenerNumero(Scanner scanner, String mensaje) {
        int numero = -1;
        while (numero == -1) {
            try {
                System.out.print(mensaje);
                numero = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer
            } catch (InputMismatchException e) {
                System.out.println("Error: Entrada inválida. Asegúrese de ingresar un número.");
                scanner.nextLine(); // Limpiar el buffer
            }
        }
        return numero;
    }

    // Metodo obtener fecha
    private static String obtenerFecha(Scanner scanner) {
        String fecha;
        while (true) {
            System.out.print("Ingrese Fecha (yyyy-mm-dd): ");
            fecha = scanner.nextLine();
            if (fecha.matches("\\d{4}-\\d{2}-\\d{2}")) {
                break; // Salir del bucle si la fecha es válida
            } else {
                System.out.println("Error: Fecha inválida. Asegúrese de usar el formato yyyy-mm-dd.");
            }
        }
        return fecha;
    }

    // Método para agregar una orden de compra
    private static void agregarOrdenCompra(Scanner scanner, GestionInventario gestionInventario) {
        int idOrden = obtenerNumero(scanner, "Ingrese ID de Orden: "); // ID de la orden
        String fechaOrden = obtenerFecha(scanner); // Fecha en formato yyyy-MM-dd
        int totalOrden = obtenerNumero(scanner, "Ingrese Total: "); // Total de la orden

        // Verificar si el ID del producto es válido antes de continuar
        int idProductoOrden;
        while (true) {
            idProductoOrden = obtenerNumero(scanner, "Ingrese ID de Producto: "); // ID del producto
            if (gestionInventario.productoDAO.existeProducto(idProductoOrden)) {
                break; // Si el producto existe, salimos del bucle
            } else {
                System.out.println(
                        "El producto con ID " + idProductoOrden + " no existe. Por favor ingrese un ID válido.");
            }
        }

        // Verificar si el ID del cliente es válido antes de continuar
        int idClienteOrden;
        while (true) {
            idClienteOrden = obtenerNumero(scanner, "Ingrese ID de Cliente: "); // ID del cliente
            try {
                if (gestionInventario.clienteDAO.existeCliente(idClienteOrden)) {
                    break; // Si el cliente existe, salimos del bucle
                } else {
                    System.out.println(
                            "El cliente con ID " + idClienteOrden + " no existe. Por favor ingrese un ID válido.");
                }
            } catch (SQLException e) {
                System.out.println("Error al verificar el cliente: " + e.getMessage());
            }
        }

        // Crear la orden de compra y agregarla
        OrdenDeCompra orden = new OrdenDeCompra(idOrden, Date.valueOf(fechaOrden), totalOrden, idProductoOrden,
                idClienteOrden);
        gestionInventario.agregarOrden(orden); // Guardar la orden de compra en la base de datos
        System.out.println("Orden de compra agregada exitosamente.");
    }

    // Método para agregar una devolución
    private static void agregarDevolucion(Scanner scanner, GestionInventario gestionInventario) {
        int idDevolucion = obtenerNumero(scanner, "Ingrese ID de Devolución: "); // ID de la devolución
        String fechaDevolucion = obtenerFecha(scanner); // Fecha de la devolución
        System.out.print("Ingrese Motivo: "); // Ingresar motivo de la devolución
        String motivoDevolucion = scanner.nextLine();

        // Validar ID de Producto
        int idProductoDevolucion;
        while (true) {
            idProductoDevolucion = obtenerNumero(scanner, "Ingrese ID de Producto: "); // ID del producto
            if (gestionInventario.productoDAO.existeProducto(idProductoDevolucion)) {
                break; // Si el producto existe, salir del bucle
            } else {
                System.out.println(
                        "El producto con ID " + idProductoDevolucion + " no existe. Por favor ingrese un ID válido.");
            }
        }

        // Validar ID de Cliente
        int idClienteDevolucion;
        while (true) {
            idClienteDevolucion = obtenerNumero(scanner, "Ingrese ID de Cliente: "); // ID del cliente
            try {
                if (gestionInventario.clienteDAO.existeCliente(idClienteDevolucion)) {
                    break; // Si el cliente existe, salir del bucle
                } else {
                    System.out.println(
                            "El cliente con ID " + idClienteDevolucion + " no existe. Por favor ingrese un ID válido.");
                }
            } catch (SQLException e) {
                System.out.println("Error al verificar el cliente: " + e.getMessage());
            }
        }

        // Crear la devolución y agregarla
        Devolucion devolucion = new Devolucion(idDevolucion, Date.valueOf(fechaDevolucion), motivoDevolucion,
                idProductoDevolucion, idClienteDevolucion);
        gestionInventario.agregarDevolucion(devolucion);
        System.out.println("Devolución agregada exitosamente."); // Mensaje de éxito
    }

    // Método para agregar venta
    private static void agregarVenta(Scanner scanner, GestionInventario gestionInventario) {
        int idVenta = obtenerNumero(scanner, "Ingrese ID de Venta: "); // ID de la venta
        String fechaVenta = obtenerFecha(scanner);
        int totalVenta = obtenerNumero(scanner, "Ingrese Total: "); // Total de la venta

        int idProductoVenta; // ID del producto
        while (true) {
            idProductoVenta = obtenerNumero(scanner, "Ingrese ID de Producto: "); // ID del producto

            if (gestionInventario.productoDAO.existeProducto(idProductoVenta)) {
                break; // Si el producto existe, salimos del ciclo
            } else {
                System.out.println("Error: El producto con ID " + idProductoVenta + " no existe en la base de datos.");
                System.out.println("Por favor, ingrese un ID de producto válido.");
            }
        }

        try {
            // Crear la venta solo si el producto es válido
            Venta venta = new Venta(idVenta, Date.valueOf(fechaVenta), totalVenta, idProductoVenta);
            gestionInventario.agregarVenta(venta);
            System.out.println("Venta agregada exitosamente.");
        } catch (IllegalArgumentException e) {
            // Este catch captura cualquier error relacionado con la conversión de fecha o
            // valores inválidos
            System.out.println("Error en los datos ingresados: " + e.getMessage());
        }
    }

    // Metodo agregar cliente
    public static void agregarCliente(Scanner scanner, GestionInventario gestionInventario) {
        int idCliente = obtenerNumero(scanner, "Ingrese ID de Cliente: "); // ID del cliente

        // Verificar si el ID ya existe en la base de datos
        try {
            if (gestionInventario.clienteDAO.existeCliente(idCliente)) {
                System.out.println("Error: El cliente con ID " + idCliente + " ya existe en la base de datos.");
                return; // Si ya existe, termina el proceso
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar si el cliente ya existe: " + e.getMessage());
            return;
        }

        // Si el ID no existe, continuar con la creación del cliente
        System.out.print("Ingrese Nombre de Usuario: ");
        String nombreUsuario = scanner.next();
        System.out.print("Ingrese Apellido: ");
        String apellido = scanner.next();
        System.out.print("Ingrese Email del Usuario: ");
        String email = scanner.next();

        // Verificar si el email tiene el formato correcto
        while (!email.contains("@")) {
            System.out.println("Error: El correo electrónico debe contener '@'. Inténtelo nuevamente.");
            System.out.print("Ingrese Email del Usuario: ");
            email = scanner.next();
        }

        // Resto de la información
        System.out.print("Ingrese Contraseña de Usuario: ");
        String contrasena = scanner.next();
        System.out.print("Ingrese Contacto de Cliente: ");
        String contacto = scanner.next();

        Cliente cliente = new Cliente(idCliente, nombreUsuario, apellido, email, contrasena, contacto);
        try {
            gestionInventario.agregarCliente(cliente);
            System.out.println("Cliente agregado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // Método para agregar un proveedor
    private static void agregarProveedor(Scanner scanner, GestionInventario gestionInventario) {
        int idProveedor;
        // Validar ID del proveedor
        while (true) {
            idProveedor = obtenerNumero(scanner, "Ingrese ID de Proveedor: "); // ID proveedor

            if (gestionInventario.proveedorDAO.existeProveedor(idProveedor)) {
                System.out.println("Error: El proveedor con ID " + idProveedor + " ya existe. Ingrese un ID único.");
            } else {
                break; // Si el ID no existe, salimos del bucle
            }
        }

        // Solicitar el resto de los datos del proveedor
        System.out.print("Ingrese Nombre de Proveedor: ");
        String nombreProveedor = scanner.nextLine();
        System.out.print("Ingrese Contacto de Proveedor: ");
        String contacto = scanner.nextLine();
        System.out.print("Ingrese Teléfono de Proveedor: ");
        String telefono = scanner.nextLine();

        int idProducto;
        // Validar ID de Producto
        while (true) {
            idProducto = obtenerNumero(scanner, "Ingrese ID de Producto asociado al proveedor: ");

            if (!gestionInventario.productoDAO.existeProducto(idProducto)) {
                System.out.println("Error: El ID de producto " + idProducto + " no existe. Ingrese un ID válido.");
            } else {
                break; // Si el ID es válido, salimos del bucle
            }
        }

        // Crear el objeto proveedor
        Proveedor proveedor = new Proveedor(idProveedor, nombreProveedor, contacto, telefono, idProducto);

        // Intentar agregar el proveedor a la base de datos
        try {
            gestionInventario.agregarProveedor(proveedor); // Ahora lanza SQLException
            System.out.println("Proveedor agregado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al agregar el proveedor: " + e.getMessage());
        }
    }

    // Método para agregar un usuario
    private static void agregarUsuario(Scanner scanner, GestionInventario gestionInventario) {
        int idUsuario;

        // Validar que el ID de usuario no exista
        while (true) {
            idUsuario = obtenerNumero(scanner, "Ingrese ID de Usuario: "); // ID de usuario

            // Verificar si el ID ya existe
            if (gestionInventario.usuarioDAO.existeUsuario(idUsuario)) {
                System.out.println("Error: El ID de usuario " + idUsuario + " ya está en uso. Ingrese un ID único.");
            } else {
                break; // Si el ID no existe, salimos del bucle
            }
        }

        // Solicitar el resto de los datos del usuario
        System.out.print("Ingrese Nombre de Usuario: ");
        String nombreUsuario = scanner.nextLine();
        System.out.print("Ingrese Apellido de Usuario: ");
        String apellido = scanner.nextLine();

        String email;

        // Validar el correo electrónico
        while (true) {
            System.out.print("Ingrese Email del Usuario: ");
            email = scanner.nextLine();
            if (email.contains("@")) {
                break; // Salir del bucle si el correo es válido
            } else {
                System.out.println("Error: El correo electrónico debe contener '@'. Inténtelo nuevamente.");
            }
        }

        System.out.print("Ingrese Contraseña de Usuario: ");
        String contrasena = scanner.nextLine();
        int idRol = obtenerNumero(scanner, "Ingrese ID Rol: ");

        // Crear el objeto usuario
        Usuario usuario = new Usuario(idUsuario, nombreUsuario, apellido, email, contrasena, idRol);

        gestionInventario.agregarUsuario(usuario);
        System.out.println("Usuario agregado exitosamente.");
    }

    // Metodo para agregar rol
    private static void agregarRol(Scanner scanner, GestionInventario gestionInventario) {

        System.out.print("Ingrese Nombre de Rol: ");
        String nombreRol = scanner.nextLine();
        System.out.print("Ingrese Descripción de Rol: ");
        String descripcion = scanner.nextLine();

        Rol rol = new Rol(0, nombreRol, descripcion);
        gestionInventario.agregarRol(rol);
        System.out.println("Rol agregado exitosamente.");
    }

    // Método para agregar categoría
    private static void agregarCategoria(Scanner scanner, GestionInventario gestionInventario) {
        // Solicitar el ID de la categoría
        int idCategoria = obtenerNumero(scanner, "Ingrese ID de Categoría: "); // El usuario ingresa el ID

        // Solicitar el nombre de la categoría
        System.out.print("Ingrese Nombre de Categoría: ");
        String nombreCategoria = scanner.nextLine(); // El usuario ingresa el nombre

        // Solicitar la descripción de la categoría
        System.out.print("Ingrese Descripción de Categoría: ");
        String descripcionCategoria = scanner.nextLine(); // El usuario ingresa la descripción

        // Crear la categoría con los datos ingresados
        Categoria categoria = new Categoria(idCategoria, nombreCategoria, descripcionCategoria);

        // Llamar a la lógica de agregar la categoría
        gestionInventario.agregarCategoria(categoria);

        // Confirmar que la categoría ha sido agregada correctamente
        System.out.println("Categoría agregada exitosamente.");
    }

    // Metodo consultar ventas
    private static void consultarVentas(GestionInventario gestionInventario) {
        try {
            List<Venta> ventas = gestionInventario.obtenerVentas(); // Llama al método obtenerVentas de
                                                                    // GestionInventario

            if (ventas.isEmpty()) {
                System.out.println("No hay ventas registradas.");
            } else {
                System.out.println("Ventas registradas:");
                for (Venta venta : ventas) {
                    System.out.println(venta); // Imprime cada venta
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar ventas: " + e.getMessage());
        }
    }

    private static double obtenerNumeroDouble(Scanner scanner, String mensaje) {
        double numero = -1;
        while (numero == -1) {
            try {
                System.out.print(mensaje);
                numero = scanner.nextDouble();
                scanner.nextLine(); // Limpiar el buffer
            } catch (InputMismatchException e) {
                System.out.println("Error: Entrada inválida. Asegúrese de ingresar un número.");
                scanner.nextLine(); // Limpiar el buffer
            }
        }
        return numero;
    }

    private static void consultarOrdenes(GestionInventario gestionInventario) {
        List<OrdenDeCompra> ordenes = gestionInventario.consultarOrdenes();
        if (ordenes == null || ordenes.isEmpty()) {
            System.out.println("No hay órdenes de compra registradas.");
        } else {
            System.out.println("Órdenes de Compra:");
            for (OrdenDeCompra orden : ordenes) {
                System.out.println(orden);
            }
        }
    }

}
