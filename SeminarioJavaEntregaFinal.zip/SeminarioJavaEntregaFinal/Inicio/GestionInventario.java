package Inicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import Modelo.Acciones.OrdenDeCompra;
import Modelo.Acciones.Venta;
import Modelo.ClasesDao.CategoriaDAO;
import Modelo.ClasesDao.ClienteDAO;
import Modelo.ClasesDao.DevolucionDAO;
import Modelo.ClasesDao.OrdenDeCompraDAO;
import Modelo.ClasesDao.ProductoDAO;
import Modelo.ClasesDao.ProveedorDAO;
import Modelo.ClasesDao.RolDAO;
import Modelo.ClasesDao.UsuarioDAO;
import Modelo.ClasesDao.VentaDAO;
import Modelo.Acciones.Devolucion;
import Modelo.Categoria;
import Modelo.Personas.Cliente;
import Modelo.Personas.Proveedor;
import Modelo.Personas.Usuario;
import Modelo.Personas.Rol;
import Modelo.Productos.Producto;
import Modelo.Productos.ProductoElectrónico;
import Modelo.Productos.ProductoNormal;
import Util.DatabaseConnection;
import java.util.InputMismatchException;

public class GestionInventario {

    // Listas para almacenar diferentes entidades del sistema
    private ArrayList<OrdenDeCompra> ordenes;
    private ArrayList<Devolucion> devoluciones;
    private ArrayList<Venta> ventas;
    private ArrayList<Categoria> categorias;
    private ArrayList<Cliente> clientes;
    private ArrayList<Proveedor> proveedores;
    private ArrayList<Usuario> usuarios;
    private ArrayList<Rol> roles;
    private ArrayList<Producto> productos;

    // DAOs para manejo de la base de datos
    private OrdenDeCompraDAO ordenDeCompraDAO;
    private Connection conexion;
    public UsuarioDAO usuarioDAO;
    ProductoDAO productoDAO;
    private DevolucionDAO devolucionDAO;
    private VentaDAO ventaDAO;
    private CategoriaDAO categoriaDAO;
    public ClienteDAO clienteDAO;
    public ProveedorDAO proveedorDAO;

    // Constructor
    public GestionInventario() {
        ordenes = new ArrayList<>();
        devoluciones = new ArrayList<>();
        ventas = new ArrayList<>();
        categorias = new ArrayList<>();
        clientes = new ArrayList<>();
        proveedores = new ArrayList<>();
        usuarios = new ArrayList<>();
        roles = new ArrayList<>();
        productos = new ArrayList<>();

        try {
            // Establecer la conexión primero
            this.conexion = DatabaseConnection.getConnection();
            System.out.println("Conexión establecida exitosamente.");

            // Ahora inicializamos los DAOs
            this.devolucionDAO = new DevolucionDAO(conexion);
            this.ventaDAO = new VentaDAO(conexion);
            this.categoriaDAO = new CategoriaDAO(conexion);
            this.clienteDAO = new ClienteDAO(conexion);
            this.ordenDeCompraDAO = new OrdenDeCompraDAO(conexion);
            this.productoDAO = new ProductoDAO(conexion);
            this.usuarioDAO = new UsuarioDAO(conexion);
            this.proveedorDAO = new ProveedorDAO(conexion);
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }

    }

    // Método para agregar una orden de compra y guardarla en la base de datos
    public void agregarOrden(OrdenDeCompra orden) {
        try {
            // Verificar si el producto existe
            if (!productoDAO.existeProducto(orden.getIdProducto())) {
                System.out.println(
                        "Error: El producto con ID " + orden.getIdProducto() + " no existe. Intente nuevamente.");
                return;
            }

            // Verificar si el cliente existe
            if (!clienteDAO.existeCliente(orden.getIdCliente())) {
                System.out.println(
                        "Error: El cliente con ID " + orden.getIdCliente() + " no existe. Intente nuevamente.");
                return;
            }

            // Si todo está correcto, agregar la orden
            ordenDeCompraDAO.agregarOrden(orden);
            ordenes.add(orden);
            System.out.println("Orden de compra agregada exitosamente en la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al agregar la orden de compra en la base de datos: " + e.getMessage());
        }
    }

    // Método para agregar una devolución
    public void agregarDevolucion(Devolucion devolucion) {
        try {
            ProductoDAO productoDAO = new ProductoDAO(conexion);
            ClienteDAO clienteDAO = new ClienteDAO(conexion);

            // Validar si el ID del producto existe
            if (!productoDAO.existeProducto(devolucion.getIdProducto())) {
                System.out.println("Error: El producto con ID " + devolucion.getIdProducto() + " no existe.");
                return; // Salir del método si el producto no existe
            }

            // Validar si el ID del cliente existe
            if (!clienteDAO.existeCliente(devolucion.getIdCliente())) {
                System.out.println("Error: El cliente con ID " + devolucion.getIdCliente() + " no existe.");
                return; // Salir del método si el cliente no existe
            }

            // Agregar la devolución si las validaciones son exitosas
            DevolucionDAO devolucionDAO = new DevolucionDAO(conexion);
            devolucionDAO.agregarDevolucion(devolucion); // Llama al DAO para guardar en la base de datos
            devoluciones.add(devolucion); // También agrega la devolución en la lista en memoria
            System.out.println("Devolución agregada exitosamente en la base de datos.");

        } catch (SQLException e) {
            System.out.println("Error al agregar la devolución en la base de datos: " + e.getMessage());
        }
    }

    // Método para agregar una venta en GestionInventario
    public void agregarVenta(Venta venta) {
        try {
            ProductoDAO productoDAO = new ProductoDAO(conexion);

            // Verificar si el producto existe antes de intentar agregar la venta
            if (!productoDAO.existeProducto(venta.getIdProducto())) {
                System.out.println(
                        "Error: El producto con ID " + venta.getIdProducto() + " no existe en la base de datos.");
                return; // Si el producto no existe, no continúa con la venta
            }

            // Si el producto existe, intenta agregar la venta en la base de datos
            VentaDAO ventaDAO = new VentaDAO(conexion);
            ventaDAO.agregarVenta(venta); // Guarda la venta en la base de datos
            ventas.add(venta); // Guarda en la lista en memoria
            System.out.println("Venta agregada exitosamente en la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al agregar la venta en la base de datos: " + e.getMessage());
        }
    }

    // Método para agregar una categoría
    public void agregarCategoria(Categoria categoria) {
        // Usamos la instancia de CategoriaDAO ya existente
        try {
            categoriaDAO.agregarCategoria(categoria);
            categorias.add(categoria);
            System.out.println("Categoría agregada exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al agregar la categoría en la base de datos: " + e.getMessage());
        }

    }

    // Metodo para agregar un cliente
    public void agregarCliente(Cliente cliente) throws SQLException {
        clientes.add(cliente);
        ClienteDAO clienteDAO = new ClienteDAO(conexion);
        clienteDAO.agregarCliente(cliente);
        System.out.println("Cliente agregado exitosamente.");
    }

    // Método para agregar un proveedor
    public void agregarProveedor(Proveedor proveedor) throws SQLException {
        ProveedorDAO proveedorDAO = new ProveedorDAO(conexion);
        proveedorDAO.agregarProveedor(proveedor);
        proveedores.add(proveedor); // Si no hay errores, agregamos el proveedor a la lista
    }

    // Método para agregar un usuario en la base de datos
    public void agregarUsuario(Usuario usuario) {
        try {
            usuarioDAO.agregarUsuario(usuario);
            System.out.println("Usuario agregado exitosamente a la base de datos.");
        } catch (SQLException e) {
            System.err.println("Error al agregar el usuario: " + e.getMessage());
        }
    }

    // Método para agregar un rol
    public void agregarRol(Rol rol) {
        try {
            RolDAO rolDAO = new RolDAO(conexion);
            rolDAO.agregarRol(rol);
            roles.add(rol);
            System.out.println("Rol agregado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al agregar rol: " + e.getMessage());
        }
    }

    // Metodo para agregar un producto
    public void agregarProducto(Scanner scanner) {
        System.out.println("Seleccione tipo de producto:");
        System.out.println("1. Producto Normal");
        System.out.println("2. Producto Electrónico");

        int tipoProducto = obtenerNumero(scanner, "Ingrese tipo: ");
        Producto producto = null;

        // Validación para que solo se ingresen tipos válidos de producto
        if (tipoProducto != 1 && tipoProducto != 2) {
            System.out.println("Tipo de producto no válido. Producto no agregado.");
            return;
        }

        // Agregar producto normal
        if (tipoProducto == 1 || tipoProducto == 2) {
            int idProducto = -1;
            // Validación para el ID del producto
            while (idProducto == -1) {
                try {
                    idProducto = obtenerNumero(scanner, "Ingrese ID de Producto: ");
                    if (idProductoExiste(idProducto)) {
                        System.out.println("Error: El ID del producto ya existe.");
                        idProducto = -1; // Volver a pedir el ID
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Error: El ID debe ser un número entero.");
                }
            }

            // Ingreso de nombre de producto
            String nombreProducto = "";
            while (nombreProducto.isEmpty()) {
                System.out.print("Ingrese Nombre de Producto: ");
                nombreProducto = scanner.nextLine();
                if (nombreProducto.isEmpty()) {
                    System.out.println("Error: El nombre no puede estar vacío.");
                }
            }

            // Validación para el precio
            double precioProducto = -1;
            while (precioProducto == -1) {
                try {
                    precioProducto = obtenerNumeroDouble(scanner, "Ingrese Precio de Producto: ");
                } catch (NumberFormatException e) {
                    System.out.println("Error: El precio debe ser un número decimal.");
                }
            }

            // Validación para el stock
            int stockProducto = -1;
            while (stockProducto == -1) {
                try {
                    stockProducto = obtenerNumero(scanner, "Ingrese Stock: ");
                    if (stockProducto < 0) {
                        System.out.println("Error: El stock no puede ser negativo.");
                        stockProducto = -1;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Error: El stock debe ser un número entero.");
                }
            }

            // Crear el producto según el tipo seleccionado
            if (tipoProducto == 1) {
                producto = new ProductoNormal(idProducto, nombreProducto, precioProducto, stockProducto);
            } else if (tipoProducto == 2) {
                String marca = "";
                while (marca.isEmpty()) {
                    System.out.print("Ingrese Marca: ");
                    marca = scanner.nextLine();
                    if (marca.isEmpty()) {
                        System.out.println("Error: La marca no puede estar vacía.");
                    }
                }

                producto = new ProductoElectrónico(idProducto, nombreProducto, precioProducto, stockProducto, marca);
            }

            // Agregar el producto
            try {
                productoDAO.agregarProducto(producto);
                productos.add(producto);
                System.out.println("Producto agregado exitosamente.");
            } catch (SQLException e) {
                System.out.println("Error al agregar producto: " + e.getMessage());
            }
        }
    }

    // Métodos para obtener las listas de las entidades
    public ArrayList<OrdenDeCompra> getOrdenes() {
        return ordenes;
    }

    public List<Venta> obtenerVentas() throws SQLException {
        return ventaDAO.obtenerVentas(); // Llama al método en VentaDAO
    }

    public List<Cliente> obtenerClientes() throws SQLException {
        return clienteDAO.obtenerClientes(); // Llama al método en ClienteDAO
    }

    public ArrayList<Devolucion> getDevoluciones() {
        return devoluciones;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public List<Cliente> getClientes() {
        List<Cliente> clientes = null;
        try {
            if (conexion == null || conexion.isClosed()) {
                System.out.println("Error: La conexión a la base de datos no está inicializada o está cerrada.");
                return clientes;
            }
            clientes = clienteDAO.obtenerClientes();
        } catch (SQLException e) {
            System.out.println("Error al obtener clientes: " + e.getMessage());
        }
        return clientes;
    }

    public List<Proveedor> getProveedores() {
        return proveedores;
    }

    public List<Usuario> getUsuarios() {
        try {
            return usuarioDAO.obtenerUsuarios();
        } catch (SQLException e) {
            System.out.println("Error al obtener usuarios: " + e.getMessage());
            return new ArrayList<>(); // Retorna una lista vacía en caso de error
        }
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    // Método para consultar el stock de productos
    public void consultarStock(Scanner scanner) {
        try {
            System.out.println("¿Desea consultar todos los productos? (S/N)");
            String respuesta = scanner.nextLine();

            if (respuesta.equalsIgnoreCase("S")) {
                List<Producto> productos = productoDAO.obtenerProductos();
                if (productos.isEmpty()) {
                    System.out.println("No hay productos en el inventario.");
                } else {
                    System.out.println("Productos en inventario:");
                    for (Producto producto : productos) {
                        System.out.println(producto);
                    }
                }
            } else {
                int idProducto = obtenerNumero(scanner, "Ingrese el ID del producto: ");
                Producto producto = productoDAO.obtenerProductoPorId(idProducto);
                if (producto != null) {
                    System.out.println("Producto encontrado: " + producto);
                } else {
                    System.out.println("Producto no encontrado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el stock: " + e.getMessage());
        }
    }

    // Metodo consultar cliente
    public void consultarClientes() {
        try {
            List<Cliente> clientes = obtenerClientes(); // Llama al método para obtener clientes
            if (clientes.isEmpty()) {
                System.out.println("No hay clientes registrados.");
            } else {
                System.out.println("Clientes:");
                for (Cliente cliente : clientes) {
                    System.out.println(cliente); //
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener clientes: " + e.getMessage());
        }
    }

    // Método para consultar devoluciones
    public void consultarDevoluciones() {
        try {
            List<Devolucion> devoluciones = devolucionDAO.obtenerDevoluciones(); // Llama al método en DevolucionDAO
            if (devoluciones.isEmpty()) {
                System.out.println("No hay devoluciones registradas.");
            } else {
                System.out.println("Devoluciones:");
                for (Devolucion devolucion : devoluciones) {
                    System.out.println(devolucion);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener devoluciones: " + e.getMessage());
        }
    }

    // Método para consultar proveedores
    public void consultarProveedores() {
        try {
            List<Proveedor> proveedores = proveedorDAO.obtenerProveedores(); // Llamamos al método de proveedorDAO
            if (proveedores.isEmpty()) {
                System.out.println("No hay proveedores registrados.");
            } else {
                System.out.println("Proveedores:");
                for (Proveedor proveedor : proveedores) {
                    System.out.println(proveedor);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener proveedores: " + e.getMessage());
        }
    }

    // Método para consultar usuarios
    public void consultarUsuarios() {
        List<Usuario> usuarios = this.getUsuarios();
        System.out.println("Usuarios encontrados: " + usuarios.size());
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
        } else {
            for (Usuario usuario : usuarios) {
                System.out.println("ID_usuario: " + usuario.getIdUsuario() +
                        ", Nombre: " + usuario.getNombre() +
                        ", Apellido: " + usuario.getApellido() +
                        ", Email: " + usuario.getEmail() +
                        ", Contraseña: " + usuario.getContrasena() +
                        ", ID_rol: " + usuario.getIdRol());
            }
        }
    }

    // Método para consultar órdenes de compra desde la base de datos
    public List<OrdenDeCompra> consultarOrdenes() {

        try {
            return ordenDeCompraDAO.obtenerOrdenes();
        } catch (SQLException e) {
            System.out.println("Error al consultar órdenes de compra: " + e.getMessage());
            return new ArrayList<>(); // Si hay error, devuelves una lista vacía
        }
    }

    // Metodo obtener numero
    private int obtenerNumero(Scanner scanner, String mensaje) {
        int numero = -1;
        while (numero == -1) {
            System.out.print(mensaje);
            try {
                numero = scanner.nextInt(); // Leer el número
                scanner.nextLine(); // Limpiar el buffer para evitar problemas con saltos de línea
            } catch (InputMismatchException e) {
                System.out.println("Error: Entrada inválida. Asegúrese de ingresar un número.");
                scanner.nextLine(); // Limpiar el buffer en caso de error
            }
        }
        return numero;
    }

    // Método privado para buscar un producto por ID
    private Producto buscarProductoPorId(int idProducto) {
        try {
            List<Producto> productos = productoDAO.obtenerProductos();
            for (Producto p : productos) {
                if (p.getId() == idProducto) {
                    return p;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar producto: " + e.getMessage());
        }
        return null;
    }

    private boolean idProductoExiste(int id) {
        for (Producto p : productos) {
            if (p.getId() == id) {
                return true;
            }
        }
        return false;
    }

    // Metodo obtener numero double
    private double obtenerNumeroDouble(Scanner scanner, String mensaje) {
        System.out.print(mensaje);
        while (!scanner.hasNextDouble()) {
            System.out.println("Entrada inválida. Intente de nuevo.");
            scanner.next();
        }
        return scanner.nextDouble();
    }

    // Método en GestionInventario para modificar un producto
    public void modificarProducto(int id, Scanner scanner) {
        Producto producto = buscarProductoPorId(id);
        if (producto != null) {
            System.out.println("Producto encontrado: " + producto);

            // Modificar los datos
            System.out.print("Ingrese nuevo nombre (dejar en blanco para no cambiar): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                producto.setNombre(nuevoNombre);
            }

            System.out.print("Ingrese nueva descripción (dejar en blanco para no cambiar): ");
            String nuevaDescripcion = scanner.nextLine();
            if (!nuevaDescripcion.isEmpty()) {
                producto.setDescripcion(nuevaDescripcion);
            } else {
                producto.setDescripcion(null); // Dejar nulo si no se ingresa nada
            }

            System.out.print("Ingrese nuevo precio (dejar en blanco para no cambiar): ");
            String precioInput = scanner.nextLine();
            if (!precioInput.isEmpty()) {
                try {
                    double nuevoPrecio = Double.parseDouble(precioInput);
                    producto.setPrecio(nuevoPrecio);
                } catch (NumberFormatException e) {
                    System.out.println("Precio no válido. No se ha cambiado el precio.");
                }
            }

            System.out.print("Ingrese nuevo stock (dejar en blanco para no cambiar): ");
            String stockInput = scanner.nextLine();
            if (!stockInput.isEmpty()) {
                try {
                    int nuevoStock = Integer.parseInt(stockInput);
                    producto.setStock(nuevoStock);
                } catch (NumberFormatException e) {
                    System.out.println("Stock no válido. No se ha cambiado el stock.");
                }
            }

            // Llamar al método de DAO para actualizar el producto en la base de datos
            try {
                productoDAO.modificarProducto(producto);
                System.out.println("Producto modificado exitosamente.");
            } catch (SQLException e) {
                System.out.println("Error al modificar el producto en la base de datos: " + e.getMessage());
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    // Método para modificar orden de compra
    public void modificarOrdenCompra(int idOrden, Scanner scanner) {
        System.out.println("==============================================");
        System.out.println("Iniciando la búsqueda de la orden con ID: " + idOrden);

        // Buscar la orden por su ID
        OrdenDeCompra orden = buscarOrdenPorId(idOrden);

        if (orden != null) {
            // Mostrar los datos actuales de la orden
            System.out.println("\nORDEN ENCONTRADA:");
            System.out.println("ID: " + orden.getIdOrden());
            System.out.println("Fecha: " + orden.getFecha());
            System.out.println("Total: " + orden.getTotal());
            System.out.println("ID Producto: " + orden.getIdProducto());

            // Confirmación para modificar
            System.out.print("\n¿Desea modificar esta orden? (S/N): ");
            String confirmacion = scanner.nextLine().trim().toUpperCase();

            if (confirmacion.equals("S")) {
                // Leer nuevos valores (con opción de dejar en blanco)
                String nuevaFecha = obtenerFecha(scanner);
                if (!nuevaFecha.isEmpty()) {
                    orden.setFecha(Date.valueOf(nuevaFecha));
                }

                String nuevoTotalStr = obtenerNumeroOptional(scanner,
                        "Ingrese el nuevo total (deje en blanco si no desea modificar): ");
                if (!nuevoTotalStr.isEmpty()) {
                    int nuevoTotal = Integer.parseInt(nuevoTotalStr);
                    orden.setTotal(nuevoTotal);
                }

                String nuevoIdProductoStr = obtenerNumeroOptional(scanner,
                        "Ingrese el nuevo ID de Producto (deje en blanco si no desea modificar): ");
                if (!nuevoIdProductoStr.isEmpty()) {
                    int nuevoIdProducto = Integer.parseInt(nuevoIdProductoStr);
                    orden.setIdProducto(nuevoIdProducto);
                }

                // Llamar al DAO para realizar la actualización en la base de datos
                try {
                    ordenDeCompraDAO.modificarOrden(orden);
                    System.out.println("\nLa orden de compra ha sido modificada exitosamente.");
                } catch (SQLException e) {
                    System.out.println("\nError al modificar la orden de compra: " + e.getMessage());
                }
            } else {
                System.out.println("\nLa modificación fue cancelada.");
            }
        } else {
            System.out.println("\nOrden de compra no encontrada.");
        }
        System.out.println("==============================================");
    }

    // Método para obtener un número de forma opcional (dejar en blanco si no lo
    // quiere modificar)
    public String obtenerNumeroOptional(Scanner scanner, String mensaje) {
        System.out.println(mensaje);
        String entrada = scanner.nextLine().trim();
        return entrada; // Devolver la entrada tal cual, si está en blanco no se modifica el campo
    }

    // Metodo modificar usuario
    public void modificarUsuario(int idUsuario, Scanner scanner) {
        // Buscar el usuario en la base de datos
        System.out.println("Buscando usuario con ID: " + idUsuario);
        Usuario usuario = usuarioDAO.buscarUsuarioPorId(idUsuario);

        // Si el usuario es encontrado, proceder con la modificación
        if (usuario != null) {
            System.out.println("Usuario encontrado: " + usuario); // Mostrar todos los datos del usuario

            // Cambiar nombre
            System.out.print("Ingrese nuevo nombre (dejar en blanco para no cambiar): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                usuario.setNombre(nuevoNombre);

            }

            // Cambiar apellido
            System.out.print("Ingrese nuevo apellido (dejar en blanco para no cambiar): ");
            String nuevoApellido = scanner.nextLine();
            if (!nuevoApellido.isEmpty()) {
                usuario.setApellido(nuevoApellido);
            }

            // Cambiar email
            System.out.print("Ingrese nuevo email (dejar en blanco para no cambiar): ");
            String nuevoEmail = scanner.nextLine();
            if (!nuevoEmail.isEmpty()) {
                // Validación simple de email
                if (nuevoEmail.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                    usuario.setEmail(nuevoEmail);
                } else {
                    System.out.println("Error: El email ingresado no es válido.");
                }
            }

            // Cambiar rol
            System.out.print("Ingrese nuevo rol (dejar en blanco para no cambiar): ");
            String nuevoRolStr = scanner.nextLine();
            if (!nuevoRolStr.isEmpty()) {
                try {
                    int nuevoRol = Integer.parseInt(nuevoRolStr);
                    usuario.setIdRol(nuevoRol);
                } catch (NumberFormatException e) {
                    System.out.println("Error: El rol debe ser un número entero.");
                }
            }

            // Llamar al DAO para modificar el usuario en la base de datos
            try {
                usuarioDAO.modificarUsuario(usuario);
                System.out.println("Usuario modificado exitosamente.");
            } catch (SQLException e) {
                // Capturar y mostrar cualquier error relacionado con la base de datos
                System.out.println("Error al modificar el usuario: " + e.getMessage());
            }
        } else {
            // Si el usuario no es encontrado, mostrar mensaje correspondiente
            System.out.println("Usuario no encontrado.");
        }
    }

    // Metodo para modificar proveedor

    public void modificarProveedor(int idProveedor, Scanner scanner) {
        Proveedor proveedor = null;

        // Intentar buscar el proveedor por ID
        try {
            proveedor = proveedorDAO.buscarProveedorPorId(idProveedor);
        } catch (SQLException e) {
            System.out.println("Error al buscar el proveedor: " + e.getMessage());
            return; // Salir del método si hay un error en la búsqueda
        }

        // Verifica si el proveedor fue encontrado
        if (proveedor != null) {
            System.out.println("Proveedor encontrado: " + proveedor);

            boolean datosValidos = false;

            while (!datosValidos) {
                try {
                    // Cambiar nombre
                    System.out.print("Ingrese nuevo nombre (dejar en blanco para no cambiar): ");
                    String nuevoNombre = scanner.nextLine().trim();
                    if (!nuevoNombre.isEmpty()) {
                        proveedor.setNombre(nuevoNombre);
                    }

                    // Cambiar contacto
                    System.out.print("Ingrese nuevo contacto (dejar en blanco para no cambiar): ");
                    String nuevoContacto = scanner.nextLine().trim();
                    if (!nuevoContacto.isEmpty()) {
                        proveedor.setContacto(nuevoContacto);
                    }

                    // Cambiar teléfono (con validación del formato)
                    String nuevoTelefono = pedirTelefonoValido(scanner, proveedor.getTelefono());
                    if (!nuevoTelefono.isEmpty()) {
                        proveedor.setTelefono(nuevoTelefono);
                    }

                    // Cambiar ID de producto (si es necesario)
                    System.out.print("Ingrese nuevo ID de producto (dejar en blanco para no cambiar): ");
                    String nuevoIdProductoStr = scanner.nextLine().trim();
                    if (!nuevoIdProductoStr.isEmpty()) {
                        try {
                            Integer nuevoIdProducto = Integer.parseInt(nuevoIdProductoStr);
                            proveedor.setIdProducto(nuevoIdProducto);
                        } catch (NumberFormatException e) {
                            System.out.println("Error: El ID de producto debe ser un número entero.");
                        }
                    }

                    // Llamar al método de ProveedorDAO para modificar en la base de datos
                    proveedorDAO.modificarProveedorEnBD(proveedor); // Llama a modificarProveedorEnBD de ProveedorDAO

                    System.out.println("Proveedor modificado exitosamente.");
                    datosValidos = true; // Si no hay errores, salir del ciclo

                } catch (SQLException e) {
                    // Error al modificar el proveedor en la base de datos
                    System.out.println("Error al modificar el proveedor: " + e.getMessage());
                } catch (IllegalArgumentException e) {
                    // Si hay errores de formato en los datos (por ejemplo, teléfono incorrecto)
                    System.out.println("Error: " + e.getMessage());
                }
            }
        } else {
            System.out.println("Proveedor no encontrado.");
        }
    }

    // Pedir telefono valido
    private String pedirTelefonoValido(Scanner scanner, String telefonoActual) {
        String telefono = "";
        while (telefono.isEmpty()) {
            System.out.print("Ingrese el nuevo teléfono (deje en blanco para no cambiar): ");
            telefono = scanner.nextLine().trim();
            // Si se deja en blanco, se regresa el teléfono actual
            if (telefono.isEmpty()) {
                return telefonoActual;
            }
            // Validación de formato del teléfono
            if (!telefono.matches("\\d{10}")) {
                System.out.println("Error: El teléfono debe tener 10 dígitos.");
                telefono = ""; // Reinicia para que el usuario lo ingrese de nuevo
            }
        }
        return telefono;
    }

    // Método para eliminar un producto y reflejarlo en la base de datos
    public void eliminarProducto(int id) {
        Producto producto = buscarProductoPorId(id);
        if (producto != null) {
            try {
                productoDAO.eliminarProducto(id); // Llama a ProductoDAO para eliminar de la base de datos
                System.out.println("Producto eliminado exitosamente de la base de datos.");
            } catch (SQLException e) {
                System.out.println("Error al eliminar el producto de la base de datos: " + e.getMessage());
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    // Método para eliminar orden de compra
    public void eliminarOrdenCompra(int idOrden) {
        OrdenDeCompra orden = buscarOrdenPorId(idOrden); // Método que busca la orden
        if (orden != null) {
            try {
                ordenDeCompraDAO.eliminarOrden(idOrden); // Llama al DAO para eliminar de la base de datos
                ordenes.remove(orden); // Elimina de la lista en memoria
                System.out.println("Orden de compra eliminada exitosamente.");
            } catch (SQLException e) {
                System.out.println("Error al eliminar la orden de compra en la base de datos: " + e.getMessage());
            }
        } else {
            System.out.println("Orden de compra no encontrada.");
        }
    }

    // Método para eliminar una devolución
    public void eliminarDevolucion(int idDevolucion) {
        Devolucion devolucion = buscarDevolucionPorId(idDevolucion);
        if (devolucion != null) {
            try {
                // Llama al método del DAO para eliminar de la base de datos
                devolucionDAO.eliminarDevolucion(idDevolucion);
                devoluciones.remove(devolucion); // Elimina de la lista en memoria
                System.out.println("Devolución eliminada exitosamente.");
            } catch (SQLException e) {
                System.out.println("Error al eliminar la devolución en la base de datos: " + e.getMessage());
            }
        } else {
            System.out.println("Devolución no encontrada.");
        }
    }

    // Método para eliminar un usuario de la base de datos y de la lista en memoria

    public void eliminarUsuario(int idUsuario) {
        try {
            // Primero, buscar el usuario por su ID
            Usuario usuario = usuarioDAO.buscarUsuarioPorId(idUsuario); // Buscar usuario en la BD

            if (usuario != null) {
                // Llamar al método de UsuarioDAO para eliminar el usuario de la base de datos
                usuarioDAO.eliminarUsuario(idUsuario);
                System.out.println("Usuario eliminado exitosamente de la base de datos.");

                // Eliminar el usuario de la lista en memoria (opcional)
                usuarios.remove(usuario); // Eliminar también de la lista de usuarios en memoria
                System.out.println("Usuario eliminado de la lista en memoria.");
            } else {
                System.out.println("Usuario no encontrado en la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        }
    }

    // Metodo para eliminar proveedor
    public void eliminarProveedor(int idProveedor) {
        try {
            proveedorDAO.eliminarProveedor(idProveedor);
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el proveedor: " + e.getMessage());
        }
    }

    // Método para buscar orden de compra por ID
    public OrdenDeCompra buscarOrdenPorId(int idOrden) {
        List<OrdenDeCompra> ordenes = consultarOrdenes(); // Obtener todas las órdenes
        System.out.println("Buscando orden con ID: " + idOrden); // Depuración

        // Buscar solo la orden con el ID proporcionado
        for (OrdenDeCompra orden : ordenes) {
            if (orden.getIdOrden() == idOrden) {
                System.out.println("Orden encontrada: " + orden); // Depuración
                return orden; // Si la encuentras, devuelves la orden
            }
        }
        return null; // Si no la encuentras, devuelves null
    }

    // Obtener fecha
    private String obtenerFecha(Scanner scanner) {
        System.out.print("Ingrese fecha (YYYY-MM-DD): ");
        String fecha = scanner.nextLine();

        return fecha;
    }

    // Buscar usuario por ID
    private Usuario buscarUsuarioPorId(int idUsuario) {
        for (Usuario usuario : usuarios) {
            if (usuario.getIdUsuario() == idUsuario) {
                return usuario;
            }
        }
        return null; // Si no se encuentra
    }

    // buscar proveedor por ID
    private Proveedor buscarProveedorPorId(int idProveedor) {
        for (Proveedor proveedor : proveedores) {
            if (proveedor.getIdProveedor() == idProveedor) {
                return proveedor;
            }
        }
        return null;
    }

    // Metodo modificar devolucion
    public void modificarDevolucion(int idDevolucionModificar, Scanner scanner) {
        // Buscar la devolución por su ID
        Devolucion devolucion = buscarDevolucionPorId(idDevolucionModificar);

        if (devolucion != null) {
            System.out.println("DEVOLUCIÓN ENCONTRADA:");
            System.out.println("ID: " + devolucion.getIdDevolucion());
            System.out.println("Fecha: " + devolucion.getFecha());
            System.out.println("Motivo: " + devolucion.getMotivo());
            System.out.println("ID Producto: " + devolucion.getIdProducto());
            System.out.println("ID Cliente: " + devolucion.getIdCliente());

            // Preguntar al usuario si desea modificar la devolución
            System.out.print("¿Desea modificar esta devolución? (S/N): ");
            String respuesta = scanner.nextLine().trim();
            if (respuesta.equalsIgnoreCase("S")) {
                boolean datosValidos = false;

                // Empezamos el proceso de actualización, solo si el usuario aceptó
                while (!datosValidos) {
                    try {
                        // Inicializamos las variables con los valores actuales
                        String nuevaFecha = devolucion.getFecha().toString();
                        String nuevoMotivo = devolucion.getMotivo();
                        int nuevoIdProducto = devolucion.getIdProducto();
                        int nuevoIdCliente = devolucion.getIdCliente();

                        // Fecha
                        String inputFecha = pedirFechaValida(scanner, nuevaFecha);

                        // Motivo
                        System.out.print("Ingrese el nuevo motivo (deje en blanco si no desea modificar): ");
                        String inputMotivo = scanner.nextLine().trim();
                        if (!inputMotivo.isEmpty()) {
                            nuevoMotivo = inputMotivo;
                            devolucion.setMotivo(nuevoMotivo);
                        }

                        // ID Producto
                        nuevoIdProducto = pedirIdProductoValido(scanner, nuevoIdProducto);
                        devolucion.setIdProducto(nuevoIdProducto);

                        // ID Cliente
                        nuevoIdCliente = pedirIdClienteValido(scanner, nuevoIdCliente);
                        devolucion.setIdCliente(nuevoIdCliente);

                        // Si todo es válido, se puede continuar con la actualización
                        datosValidos = true;

                        // Realizar la actualización en la base de datos
                        devolucionDAO.modificarDevolucion(devolucion);
                        System.out.println("La devolución ha sido modificada exitosamente.");

                    } catch (SQLException e) {
                        // Captura errores de SQL
                        System.out.println("Error al modificar la devolución: " + e.getMessage());
                        // No cambiamos `datosValidos` para que vuelva a intentar
                    }
                }
            } else {
                System.out.println("No se ha modificado la devolución.");
            }
        } else {
            System.out.println("Devolución no encontrada.");
        }
    }

    private String pedirFechaValida(Scanner scanner, String fechaActual) {
        while (true) {
            try {
                System.out.print("Ingrese fecha (YYYY-MM-DD) (deje en blanco si no desea modificar): ");
                String inputFecha = scanner.nextLine().trim();
                if (inputFecha.isEmpty()) {
                    return fechaActual; // Si está vacío, se mantiene la fecha actual
                }
                // Intentamos convertir la fecha al formato correcto
                Date fecha = Date.valueOf(inputFecha);
                return inputFecha; // Si es válido, retornamos la fecha ingresada
            } catch (IllegalArgumentException e) {
                // Si el formato de la fecha es incorrecto, mostramos el error y pedimos de
                // nuevo
                System.out.println("Error: La fecha debe tener el formato YYYY-MM-DD.");
            }
        }
    }

    private int pedirIdProductoValido(Scanner scanner, int idProductoActual) {
        while (true) {
            try {
                System.out.print("Ingrese el nuevo ID de Producto (deje en blanco si no desea modificar): ");
                String inputProducto = scanner.nextLine().trim();
                if (inputProducto.isEmpty()) {
                    return idProductoActual; // Si está vacío, se mantiene el ID actual
                }
                int nuevoIdProducto = Integer.parseInt(inputProducto);
                if (verificarProductoExiste(nuevoIdProducto)) {
                    return nuevoIdProducto;
                } else {
                    System.out.println("Error: El ID de producto ingresado no existe en la base de datos.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: El ID de producto debe ser un número válido.");
            }
        }
    }

    private int pedirIdClienteValido(Scanner scanner, int idClienteActual) {
        while (true) {
            try {
                System.out.print("Ingrese el nuevo ID de Cliente (deje en blanco si no desea modificar): ");
                String inputCliente = scanner.nextLine().trim();
                if (inputCliente.isEmpty()) {
                    return idClienteActual; // Si está vacío, se mantiene el ID actual
                }
                int nuevoIdCliente = Integer.parseInt(inputCliente);
                if (verificarClienteExiste(nuevoIdCliente)) {
                    return nuevoIdCliente;
                } else {
                    System.out.println("Error: El ID de cliente ingresado no existe en la base de datos.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: El ID de cliente debe ser un número válido.");
            }
        }
    }

    public boolean verificarProductoExiste(int idProducto) {
        String sql = "SELECT COUNT(*) FROM Producto WHERE ID_producto = ?";
        try (PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setInt(1, idProducto);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; // Devuelve true si el producto existe
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar el producto: " + e.getMessage());
        }
        return false;
    }

    public boolean verificarClienteExiste(int idCliente) {
        String sql = "SELECT COUNT(*) FROM Cliente WHERE ID_cliente = ?";
        try (PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setInt(1, idCliente);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; // Devuelve true si el cliente existe
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar el cliente: " + e.getMessage());
        }
        return false;
    }

    public Devolucion buscarDevolucionPorId(int idDevolucion) {
        Devolucion devolucion = null;
        String sql = "SELECT * FROM Devolucion WHERE ID_devolucion = ?";

        try (PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setInt(1, idDevolucion);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {

                int id = resultSet.getInt("ID_devolucion");
                Date fecha = resultSet.getDate("fecha");
                String motivo = resultSet.getString("motivo");
                int idProducto = resultSet.getInt("ID_producto");
                int idCliente = resultSet.getInt("ID_cliente");

                devolucion = new Devolucion(id, fecha, motivo, idProducto, idCliente);
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar la devolución: " + e.getMessage());
        }

        return devolucion;
    }

}